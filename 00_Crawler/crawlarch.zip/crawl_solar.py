

def crawl_solar():
	
	
	
	return 0
